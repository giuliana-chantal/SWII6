﻿using Microsoft.AspNetCore.Mvc;
using Prova_Web.Models;
using Prova_Web.Service;
using System.Diagnostics;

namespace Prova_Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly AuthService authService;
        private readonly ProductsService productsService;

        public HomeController(AuthService authService, ProductsService productsService)
        {
            this.authService = authService;
            this.productsService = productsService;

        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(Auth auth)
        {
            if (ModelState.IsValid)
            {
                var user = await authService.SignIn(auth);
                productsService.User = user.Id;

                return RedirectToAction("", "Products");
            }
            return View(auth);
        }
    }
}