﻿namespace Prova_Web.Models
{
    public class Auth
    {
        public string Login { get; set; }
        public string Senha { get; set; }
    }
}
