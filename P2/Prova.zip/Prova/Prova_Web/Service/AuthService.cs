﻿using Newtonsoft.Json;
using Prova_Web.Models;

namespace Prova_Web.Service
{
    public class AuthService
    {
        private string baseURL = "http://localhost:5296";

        public async Task<Product> SignIn(Auth auth)
        {
            var client = new HttpClient();

            var request = new HttpRequestMessage(HttpMethod.Post, $"{baseURL}/users/signin");


            var content = JsonConvert.SerializeObject(auth);

            request.Content = new StringContent(content, null, "application/json");
            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var usuario = JsonConvert.DeserializeObject<Product>(await response.Content.ReadAsStringAsync());

            return usuario;
        }

    }
}
