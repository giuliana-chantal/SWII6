﻿using Microsoft.EntityFrameworkCore;
using Prova_API.Models;

namespace Prova_API.Repositorys
{
    public class UserRepository
    {
        private readonly ProvaContext _context;

        public UserRepository(ProvaContext context)
        {
            _context = context;
        }

        public async Task<List<User>> Index()
        {
            return await _context.Users.ToListAsync();
        }

        public async Task<User> Details(int? id)
        {
            return await _context.Users.FirstOrDefaultAsync(m => m.Id == id);
        }

        public async Task<bool> Create(User user)
        {
            _context.Add(user);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> Edit(int id, User user)
        {
            var userDb = await _context.Users.FindAsync(id);
            if (userDb != null)
            {
                userDb.Nome = user.Nome;
                userDb.Senha = user.Senha;
                userDb.Status = user.Status;

                _context.Update(userDb);
                await _context.SaveChangesAsync();
                return true;
            }

            return false;
        }

        public async Task<bool> Delete(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user != null)
            {
                _context.Users.Remove(user);
                await _context.SaveChangesAsync();
                return true;
            }

            return false;
        }

        public async Task<User> SingIn(string nome, string senha)
        {
            return await _context.Users.FirstOrDefaultAsync(m => m.Status && m.Nome == nome && m.Senha == senha);
        }
    }
}
