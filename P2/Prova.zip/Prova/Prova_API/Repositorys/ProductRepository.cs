﻿using Microsoft.EntityFrameworkCore;
using Prova_API.Models;

namespace Prova_API.Repositorys
{
    public class ProductRepository
    {
        private readonly ProvaContext _context;

        public ProductRepository(ProvaContext context)
        {
            _context = context;
        }

        public async Task<List<Product>> Index()
        {
            return await _context.Products.ToListAsync();
        }

        public async Task<Product> Details(int? id)
        {
            return await _context.Products.FirstOrDefaultAsync(m => m.Id == id);
        }

        public async Task<bool> Create(Product product)
        {
            _context.Add(product);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> Edit(int id, Product product)
        {
            var productDb = await _context.Products.FindAsync(id);
            if (productDb != null)
            {
                productDb.Nome = product.Nome;
                productDb.Preco = product.Preco;
                productDb.Status = product.Status;
                productDb.IdUsuarioUpdate = product.IdUsuarioUpdate;

                _context.Update(productDb);
                await _context.SaveChangesAsync();
                return true;
            }

            return false;
        }

        public async Task<bool> Delete(int id)
        {
            if (_context.Products == null)
            {
                return false;
            }

            var product = await _context.Products.FindAsync(id);
            if (product != null)
            {
                _context.Products.Remove(product);
                await _context.SaveChangesAsync();
                return true;
            }

            return false;
        }
    }
}
