using Microsoft.EntityFrameworkCore;
using Prova_API;
using Prova_API.Repositorys;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddTransient<UserRepository>();
builder.Services.AddTransient<ProductRepository>();

var connection = builder.Configuration.GetSection("ConnectionStringSqlite").Value;
builder.Services.AddDbContext<ProvaContext>(options =>
    options.UseSqlite(connection)
);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
