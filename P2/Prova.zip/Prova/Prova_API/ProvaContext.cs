﻿using Microsoft.EntityFrameworkCore;
using Prova_API.Models;

namespace Prova_API
{
    public class ProvaContext : DbContext
    {
        public ProvaContext(DbContextOptions<ProvaContext> options) : base(options)
        {
        }
        public DbSet<Product> Products { get; set; }
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<Product>().HasKey(m => m.Id);
            builder.Entity<User>().HasKey(m => m.Id);

            base.OnModelCreating(builder);
        }
    }
}
