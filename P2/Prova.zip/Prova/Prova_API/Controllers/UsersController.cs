﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Prova_API.Models;
using Prova_API.Repositorys;

namespace Prova_API.Controllers
{
    [Route("users")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly UserRepository userRepository;

        public UsersController(UserRepository userRepository)
        {
            this.userRepository = userRepository;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var users = await userRepository.Index();
            return Ok(users);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Details(int? id)
        {
            var user = await userRepository.Details(id);
            return Ok(user);
        }

        [HttpPost]
        public async Task<IActionResult> Create(User user)
        {
            var success = await userRepository.Create(user);
            if (success)
            {
                return Ok();
            }

            return BadRequest();
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Edit(int id, User user)
        {
            var success = await userRepository.Edit(id, user);
            if (success)
            {
                return Ok();
            }

            return BadRequest();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var success = await userRepository.Delete(id);
            return RedirectToAction(nameof(Index));
        }

        [HttpPost("signin")]
        public async Task<IActionResult> SignIn(Auth login)
        {
            var user = await userRepository.SingIn(login.Login, login.Senha);

            if (user != null)
            {
                return Ok(user);
            }

            return Unauthorized();
        }
    }
}
