﻿namespace Prova_Desktop
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            usersGrid = new DataGridView();
            btnExcluir = new Button();
            btnEditar = new Button();
            btnNovo = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)usersGrid).BeginInit();
            SuspendLayout();
            // 
            // usersGrid
            // 
            usersGrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            usersGrid.Location = new Point(12, 82);
            usersGrid.Name = "usersGrid";
            usersGrid.RowTemplate.Height = 25;
            usersGrid.Size = new Size(776, 341);
            usersGrid.TabIndex = 0;
            // 
            // btnExcluir
            // 
            btnExcluir.Location = new Point(705, 41);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(83, 23);
            btnExcluir.TabIndex = 1;
            btnExcluir.Text = "Excluir";
            btnExcluir.UseVisualStyleBackColor = true;
            btnExcluir.Click += btnExcluir_Click;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(616, 41);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(83, 23);
            btnEditar.TabIndex = 2;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            btnEditar.Click += btnEditar_Click;
            // 
            // btnNovo
            // 
            btnNovo.Location = new Point(527, 41);
            btnNovo.Name = "btnNovo";
            btnNovo.Size = new Size(83, 23);
            btnNovo.TabIndex = 3;
            btnNovo.Text = "Novo";
            btnNovo.UseVisualStyleBackColor = true;
            btnNovo.Click += btnNovo_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(489, 444);
            label1.Name = "label1";
            label1.Size = new Size(299, 15);
            label1.TabIndex = 4;
            label1.Text = "Desenvolvido por Giuliana Ferreira Chantal - CB3013171";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 468);
            Controls.Add(label1);
            Controls.Add(btnNovo);
            Controls.Add(btnEditar);
            Controls.Add(btnExcluir);
            Controls.Add(usersGrid);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)usersGrid).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView usersGrid;
        private Button btnExcluir;
        private Button btnEditar;
        private Button btnNovo;
        private Label label1;
    }
}