﻿using Newtonsoft.Json;
using Prova_Desktop.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prova_Desktop.Services
{
    public class UserService
    {
        private string baseURL = "http://localhost:5296";

        public async Task<List<User>> Index()
        {
            var client = new HttpClient();

            var request = new HttpRequestMessage(HttpMethod.Get, $"{baseURL}/users");

            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var users = JsonConvert.DeserializeObject<List<User>>(await response.Content.ReadAsStringAsync());

            return users;
        }

        public async Task<User> Details(int? id)
        {
            var client = new HttpClient();

            var request = new HttpRequestMessage(HttpMethod.Get, $"{baseURL}/users/{id}");

            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var user = JsonConvert.DeserializeObject<User>(await response.Content.ReadAsStringAsync());

            return user;
        }

        public async Task Create(User user)
        {
            var client = new HttpClient();

            var request = new HttpRequestMessage(HttpMethod.Post, $"{baseURL}/users");

            var content = JsonConvert.SerializeObject(user);

            request.Content = new StringContent(content, null, "application/json");
            var response = await client.SendAsync(request);
        }

        public async Task Edit(int id, User user)
        {
            var client = new HttpClient();

            var request = new HttpRequestMessage(HttpMethod.Put, $"{baseURL}/users/{id}");

            var content = JsonConvert.SerializeObject(user);

            request.Content = new StringContent(content, null, "application/json");
            var response = await client.SendAsync(request);
        }

        public async Task Delete(int id)
        {
            var client = new HttpClient();

            var request = new HttpRequestMessage(HttpMethod.Delete, $"{baseURL}/users/{id}");

            var response = await client.SendAsync(request);
        }
    }
}
