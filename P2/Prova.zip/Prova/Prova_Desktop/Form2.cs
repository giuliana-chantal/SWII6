﻿using Prova_Desktop.Models;
using Prova_Desktop.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prova_Desktop
{
    public partial class Form2 : Form
    {
        private User User;
        private readonly UserService userService;

        public Form2(User user = null)
        {
            User = user;
            userService = new UserService();
            InitializeComponent();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            if (User == null)
            {
                lblEditar.Visible = false;
                lblAdicionar.Visible = true;
            }
            else
            {
                lblEditar.Visible = true;
                lblAdicionar.Visible = false;

                txtNome.Text = User.Nome;
                txtSenha.Text = User.Senha;
                Ativo.Checked = User.Status;
                Inativo.Checked = !User.Status;
            }
        }

        private async void btnSalvar_Click(object sender, EventArgs e)
        {
            var user = new User()
            {
                Nome = txtNome.Text,
                Senha = txtSenha.Text,
                Status = Ativo.Checked
            };

            if (User == null) {
                await userService.Create(user);
            }
            else
            {
                await userService.Edit(User.Id, user);
            }

            this.Close();
        }
    }
}
