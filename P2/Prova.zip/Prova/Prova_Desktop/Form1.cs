using Prova_Desktop.Models;
using Prova_Desktop.Services;
using System.Windows.Forms;

namespace Prova_Desktop
{
    public partial class Form1 : Form
    {
        private readonly UserService userService;
        public Form1()
        {
            userService = new UserService();
            InitializeComponent();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            var form = new Form2();
            form.FormClosed += Form1_Load;
            form.ShowDialog();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            var user = getUserSelected();
            var form = new Form2(user);
            form.FormClosed += Form1_Load;
            form.ShowDialog();
        }

        private async void btnExcluir_Click(object sender, EventArgs e)
        {
            var user = getUserSelected();
            await userService.Delete(user.Id);
            Form1_Load(sender, e);
        }

        private async void Form1_Load(object sender, EventArgs e)
        {
            var users = await userService.Index();
            usersGrid.DataSource = users;
        }

        private User getUserSelected()
        {
            var usuarios = (List<User>)usersGrid.DataSource;

            return usuarios[usersGrid.SelectedRows[0].Index];
        }
    }
}