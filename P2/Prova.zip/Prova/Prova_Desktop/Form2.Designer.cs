﻿namespace Prova_Desktop
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnSalvar = new Button();
            btnCancelar = new Button();
            txtNome = new TextBox();
            txtSenha = new TextBox();
            Ativo = new RadioButton();
            Inativo = new RadioButton();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            lblAdicionar = new Label();
            lblEditar = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(119, 374);
            label1.Name = "label1";
            label1.Size = new Size(299, 15);
            label1.TabIndex = 5;
            label1.Text = "Desenvolvido por Giuliana Ferreira Chantal - CB3013171";
            // 
            // btnSalvar
            // 
            btnSalvar.Location = new Point(314, 321);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(104, 23);
            btnSalvar.TabIndex = 6;
            btnSalvar.Text = "Salvar";
            btnSalvar.UseVisualStyleBackColor = true;
            btnSalvar.Click += btnSalvar_Click;
            // 
            // btnCancelar
            // 
            btnCancelar.Location = new Point(25, 321);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(104, 23);
            btnCancelar.TabIndex = 7;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // txtNome
            // 
            txtNome.Location = new Point(25, 127);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(393, 23);
            txtNome.TabIndex = 8;
            // 
            // txtSenha
            // 
            txtSenha.Location = new Point(25, 197);
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(393, 23);
            txtSenha.TabIndex = 9;
            // 
            // Ativo
            // 
            Ativo.AutoSize = true;
            Ativo.Checked = true;
            Ativo.Location = new Point(35, 275);
            Ativo.Name = "Ativo";
            Ativo.Size = new Size(53, 19);
            Ativo.TabIndex = 10;
            Ativo.TabStop = true;
            Ativo.Text = "Ativo";
            Ativo.UseVisualStyleBackColor = true;
            // 
            // Inativo
            // 
            Inativo.AutoSize = true;
            Inativo.Location = new Point(119, 275);
            Inativo.Name = "Inativo";
            Inativo.Size = new Size(61, 19);
            Inativo.TabIndex = 11;
            Inativo.Text = "Inativo";
            Inativo.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(25, 99);
            label2.Name = "label2";
            label2.Size = new Size(43, 15);
            label2.TabIndex = 12;
            label2.Text = "Nome:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(25, 169);
            label3.Name = "label3";
            label3.Size = new Size(42, 15);
            label3.TabIndex = 13;
            label3.Text = "Senha:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(25, 243);
            label4.Name = "label4";
            label4.Size = new Size(42, 15);
            label4.TabIndex = 14;
            label4.Text = "Status:";
            // 
            // lblAdicionar
            // 
            lblAdicionar.Anchor = AnchorStyles.None;
            lblAdicionar.AutoSize = true;
            lblAdicionar.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            lblAdicionar.Location = new Point(142, 32);
            lblAdicionar.Name = "lblAdicionar";
            lblAdicionar.Size = new Size(130, 37);
            lblAdicionar.TabIndex = 15;
            lblAdicionar.Text = "Adicionar";
            lblAdicionar.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblEditar
            // 
            lblEditar.Anchor = AnchorStyles.None;
            lblEditar.AutoSize = true;
            lblEditar.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point);
            lblEditar.Location = new Point(158, 32);
            lblEditar.Name = "lblEditar";
            lblEditar.Size = new Size(86, 37);
            lblEditar.TabIndex = 16;
            lblEditar.Text = "Editar";
            lblEditar.TextAlign = ContentAlignment.MiddleCenter;
            lblEditar.Visible = false;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(430, 407);
            Controls.Add(lblEditar);
            Controls.Add(lblAdicionar);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(Inativo);
            Controls.Add(Ativo);
            Controls.Add(txtSenha);
            Controls.Add(txtNome);
            Controls.Add(btnCancelar);
            Controls.Add(btnSalvar);
            Controls.Add(label1);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnSalvar;
        private Button btnCancelar;
        private TextBox txtNome;
        private TextBox txtSenha;
        private RadioButton Ativo;
        private RadioButton Inativo;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label lblAdicionar;
        private Label lblEditar;
    }
}